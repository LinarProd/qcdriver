// SPDX-License-Identifier: GPL-2.0
/*
 * Presonus Studio 1810c driver for ALSA
 * Copyright (C) 2019 Nick Kossifidis <mickflemm@gmail.com>
 *
 * Based on reverse engineering of the communication protocol
 * between the windows driver / Univeral Control (UC) program
 * and the device, through usbmon.
 *
 * For now this bypasses the mixer, with all channels split,
 * so that the software can mix with greater flexibility.
 * It also adds controls for the 4 buttons on the front of
 * the device.
 */

#include <linux/usb.h>
#include <linux/usb/audio-v2.h>
#include <linux/slab.h>
#include <sound/core.h>
#include <sound/control.h>

#include "usbaudio.h"
#include "mixer.h"
#include "mixer_quirks.h"
#include "helper.h"
#include "mixer_s1810c.h"

/*
 * DISCLAIMER: These are just guesses based on the
 * dumps I got.
 *
 * It seems like a selects between
 * device (0), mixer (0x64) and output (0x65)
 *
 * For mixer (0x64):
 *  * b selects an input channel (see below).
 *  * c selects an output channel pair (see below).
 *  * d selects left (0) or right (1) of that pair.
 *  * e level : see MIXER_LEVEL_* defines below.
 *	Also used for setting volume levels
 *	in which case b is also set so I guess
 *	this way it is possible to set the volume
 *	level from the specified input to the
 *	specified output.
 *
 * IN Channels:
 * 0  - 7  Mic/Inst/Line (Analog inputs)
 * 8  - 9  S/PDIF
 * 10 - 17 ADAT
 * 18 - 35 DAW (Inputs from the host)
 *
 * OUT Channels (pairs):
 * 0 -> Main out
 * 1 -> Line1/2
 * 2 -> Line3/4
 * 3 -> S/PDIF
 * 4 -> ADAT?
 *
 * For device (0):
 *  * b and c are not used, at least not on the
 *    dumps I got.
 *  * d sets the control id to be modified
 *    (see below).
 *  * e sets the setting for that control.
 *    (so for the switches I was interested
 *    in it's 0/1)
 *
 * For output (0x65):
 *   * b is the output channel (see above).
 *   * c is zero.
 *   * e I guess the same as with mixer
 *
 */
/* struct s1810c_ctl_packet - basic vendor request
 * @selector: device/mixer/output
 * @b: request-dependant field b
 * @tag: fixed value identifying type of request
 * @len: sizeof this struct - 8 (excludes first 2 fields)
 *	i.e. for basic struct s1810c_ctl_packet: len is 5*4=0x14
 * @c: request-dependant field c
 * @d: request-dependant field d
 * @e: request-dependant field e
 *
 * See longer description above. This could be combined
 * (as a union?) with the longer struct s1810c_state_packet
 */
struct s1810c_ctl_packet {
	__le32 selector;
	__le32 b;
	__le32 tag;
	__le32 len;
	__le32 c;
	__le32 d;
	__le32 e;
};

/* selectors for CMD request
 */
#define SC1810C_SEL_DEVICE 0
#define SC1810C_SEL_MIXER 0x64
#define SC1810C_SEL_OUTPUT 0x65


/* control ids */
#define SC1810C_CTL_LINE_SW	0
#define SC1810C_CTL_MUTE_SW	1
#define SC1824C_CTL_MONO_SW	2
#define SC1810C_CTL_AB_SW	3
#define SC1810C_CTL_48V_SW	4

/* USB Control (vendor) requests
 */
#define SC1810C_CMD_REQ	160
#define SC1810C_CMD_REQTYPE \
	(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_DIR_OUT)
#define SC1810C_CMD_TAG		0x50617269
#define SC1810C_CMD_LEN		0x14

#define SC1810C_SET_STATE_REQ	161
#define SC1810C_SET_STATE_REQTYPE SC1810C_CMD_REQTYPE
#define SC1810C_SET_STATE_TAG	0x64656D73
#define SC1810C_SET_STATE_LEN	0xF4

#define SC1810C_GET_STATE_REQ	162
#define SC1810C_GET_STATE_REQTYPE \
	(USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_DIR_IN)
#define SC1810C_GET_STATE_TAG	SC1810C_SET_STATE_TAG
#define SC1810C_GET_STATE_LEN	SC1810C_SET_STATE_LEN

/* Mixer levels normally range from 0 (off) to 0x0100 0000 (0 dB).
 * raw_level = 2^24 * 10^(db_level / 20), thus
 * -3dB = 0xb53bf0 (technically, half-power -3.01...dB would be 0xb504f3)
 * -96dB = 0x109
 * -99dB = 0xBC
 * PC software sliders cover -96 to +10dB (0x0329 8b08),
 * but the value 0 (-inf dB) can be used when e.g. Mixer Bypass is enabled.
 * Unclear what the hardware's maximum value is.
 *
 * Note, when a channel is panned to two channels (stereo),
 * the mixer level is set to slider value (by default -96dB) minus 3dB,
 * which explains the -99dB value seen in USB captures.
 */
#define MIXER_LEVEL_MUTE 0
#define MIXER_LEVEL_N99DB 0xbc
#define MIXER_LEVEL_N3DB 0xb53bf0
#define MIXER_LEVEL_0DB 0x1000000

/*
 * This packet includes mixer volumes and
 * various other fields, it's an extended
 * version of ctl_packet, with a and b
 * being zero and different tag/length.
 */
struct s1810c_state_packet {
	__le32 fields[63];
};

/* indices into s1810c_state_packet.fields[]
 */
#define SC1810C_STATE_TAG_IDX	2
#define SC1810C_STATE_LEN_IDX	3

#define SC1810C_STATE_48V_SW	58
#define SC1810C_STATE_LINE_SW	59
#define SC1810C_STATE_MUTE_SW	60
#define SC1824C_STATE_MONO_SW	61
#define SC1810C_STATE_AB_SW	62

struct s1810_mixer_state {
	uint16_t seqnum;
	struct mutex usb_mutex;
	struct mutex data_mutex;
};

static int
snd_s1810c_send_ctl_packet(struct usb_device *dev, u32 sel,
			   u32 b, u32 c, u32 d, u32 e)
{
	struct s1810c_ctl_packet pkt = { 0 };
	int ret = 0;

	pkt.tag = __cpu_to_le32(SC1810C_CMD_TAG);
	pkt.len = __cpu_to_le32(SC1810C_CMD_LEN);

	pkt.selector = __cpu_to_le32(sel);
	pkt.b = __cpu_to_le32(b);
	pkt.c = __cpu_to_le32(c);
	pkt.d = __cpu_to_le32(d);
	pkt.e = __cpu_to_le32(e);

	ret = snd_usb_ctl_msg(dev, usb_sndctrlpipe(dev, 0),
			      SC1810C_CMD_REQ,
			      SC1810C_CMD_REQTYPE, 0, 0, &pkt, sizeof(pkt));
	if (ret < 0) {
		dev_warn(&dev->dev, "could not send ctl packet\n");
		return ret;
	}
	return 0;
}

/*
 * When opening Universal Control the program periodically
 * sends and receives state packets for syncinc state between
 * the device and the host.
 *
 * Note that if we send only the request to get data back we'll
 * get an error, we need to first send an empty state packet and
 * then ask to receive a filled. Their seqnumbers must also match.
 */
static int
snd_sc1810c_get_status_field(struct usb_device *dev,
			     u32 *field, int field_idx, uint16_t *seqnum)
{
	struct s1810c_state_packet pkt_out = { { 0 } };
	struct s1810c_state_packet pkt_in = { { 0 } };
	int ret = 0;

	pkt_out.fields[SC1810C_STATE_TAG_IDX] = __cpu_to_le32(SC1810C_SET_STATE_TAG);
	pkt_out.fields[SC1810C_STATE_LEN_IDX] = __cpu_to_le32(SC1810C_SET_STATE_LEN);
	ret = snd_usb_ctl_msg(dev, usb_sndctrlpipe(dev, 0),
			      SC1810C_SET_STATE_REQ,
			      SC1810C_SET_STATE_REQTYPE,
			      (*seqnum), 0, &pkt_out, sizeof(pkt_out));
	if (ret < 0) {
		dev_warn(&dev->dev, "could not send state packet (%d)\n", ret);
		return ret;
	}

	ret = snd_usb_ctl_msg(dev, usb_rcvctrlpipe(dev, 0),
			      SC1810C_GET_STATE_REQ,
			      SC1810C_GET_STATE_REQTYPE,
			      (*seqnum), 0, &pkt_in, sizeof(pkt_in));
	if (ret < 0) {
		dev_warn(&dev->dev, "could not get state field %u (%d)\n",
			 field_idx, ret);
		return ret;
	}

	(*field) = __le32_to_cpu(pkt_in.fields[field_idx]);
	(*seqnum)++;
	return 0;
}

/*
 * This is what I got when bypassing the mixer with
 * all channels split. I'm not 100% sure of what's going
 * on, I could probably clean this up based on my observations
 * but I prefer to keep the same behavior as the windows driver.
 */
static int snd_s1810c_init_mixer_maps(struct snd_usb_audio *chip)
{
	u32 a, b, c, e, n, off, left, right;
	struct usb_device *dev = chip->dev;

	switch (chip->usb_id) {
	case USB_ID(0x194f, 0x010c): /* 1810c */
		/* Set initial volume levels ? */
		a = SC1810C_SEL_MIXER;
		e = MIXER_LEVEL_N99DB;
		for (n = 0; n < 2; n++) {
			off = n * 18;
			for (b = off; b < 18 + off; b++) {
				/* This channel to all outputs ? */
				for (c = 0; c <= 8; c++) {
					snd_s1810c_send_ctl_packet(dev, a, b, c, 0, e);
					snd_s1810c_send_ctl_packet(dev, a, b, c, 1, e);
				}
				/* This channel to main output (again) */
				snd_s1810c_send_ctl_packet(dev, a, b, 0, 0, e);
				snd_s1810c_send_ctl_packet(dev, a, b, 0, 1, e);
			}
			/*
			 * I noticed on UC that DAW channels have different
			 * initial volumes, so this makes sense.
			 */
			e = MIXER_LEVEL_N3DB;
		}

		/* Connect analog outputs ? */
		a = SC1810C_SEL_OUTPUT;
		for (b = 1; b < 3; b++) {
			snd_s1810c_send_ctl_packet(dev, a, b, 0, 0, MIXER_LEVEL_0DB);
			snd_s1810c_send_ctl_packet(dev, a, b, 0, 1, MIXER_LEVEL_0DB);
		}
		snd_s1810c_send_ctl_packet(dev, a, 0, 0, 0, MIXER_LEVEL_0DB);
		snd_s1810c_send_ctl_packet(dev, a, 0, 0, 1, MIXER_LEVEL_0DB);

		/* Set initial volume levels for S/PDIF mappings ? */
		a = SC1810C_SEL_MIXER;
		e = MIXER_LEVEL_N99DB;
		c = 3;
		for (n = 0; n < 2; n++) {
			off = n * 18;
			for (b = off; b < 18 + off; b++) {
				snd_s1810c_send_ctl_packet(dev, a, b, c, 0, e);
				snd_s1810c_send_ctl_packet(dev, a, b, c, 1, e);
			}
			e = MIXER_LEVEL_N3DB;
		}

		/* Connect S/PDIF output ? */
		a = SC1810C_SEL_OUTPUT;
		snd_s1810c_send_ctl_packet(dev, a, 3, 0, 0, MIXER_LEVEL_0DB);
		snd_s1810c_send_ctl_packet(dev, a, 3, 0, 1, MIXER_LEVEL_0DB);

		/* Connect all outputs (again) ? */
		a = SC1810C_SEL_OUTPUT;
		for (b = 0; b < 4; b++) {
			snd_s1810c_send_ctl_packet(dev, a, b, 0, 0, MIXER_LEVEL_0DB);
			snd_s1810c_send_ctl_packet(dev, a, b, 0, 1, MIXER_LEVEL_0DB);
		}

		/* Basic routing to get sound out of the device */
		a = SC1810C_SEL_MIXER;
		for (c = 0; c < 4; c++) {
			for (b = 0; b < 36; b++) {
				if ((c == 0 && b == 18) ||	/* DAW1/2 -> Main */
					(c == 1 && b == 20) ||	/* DAW3/4 -> Line3/4 */
					(c == 2 && b == 22) ||	/* DAW4/5 -> Line5/6 */
					(c == 3 && b == 24)) {	/* DAW5/6 -> S/PDIF */
					/* Left */
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 0, MIXER_LEVEL_0DB);
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 1, MIXER_LEVEL_MUTE);
					b++;
					/* Right */
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 0, MIXER_LEVEL_MUTE);
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 1, MIXER_LEVEL_0DB);
				} else {
					/* Leave the rest disconnected */
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 0, MIXER_LEVEL_MUTE);
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 1, MIXER_LEVEL_MUTE);
				}
			}
		}

		/* Set initial volume levels for S/PDIF (again) ? */
		a = SC1810C_SEL_MIXER;
		e = MIXER_LEVEL_N99DB;
		c = 3;
		for (n = 0; n < 2; n++) {
			off = n * 18;
			for (b = off; b < 18 + off; b++) {
				snd_s1810c_send_ctl_packet(dev, a, b, c, 0, e);
				snd_s1810c_send_ctl_packet(dev, a, b, c, 1, e);
			}
			e = MIXER_LEVEL_N3DB;
		}

		/* Connect S/PDIF outputs (again) ? */
		a = SC1810C_SEL_OUTPUT;
		snd_s1810c_send_ctl_packet(dev, a, 3, 0, 0, MIXER_LEVEL_0DB);
		snd_s1810c_send_ctl_packet(dev, a, 3, 0, 1, MIXER_LEVEL_0DB);

		/* Again ? */
		snd_s1810c_send_ctl_packet(dev, a, 3, 0, 0, MIXER_LEVEL_0DB);
		snd_s1810c_send_ctl_packet(dev, a, 3, 0, 1, MIXER_LEVEL_0DB);
		break;

	case USB_ID(0x194f, 0x0107): /* 1824 */
	case USB_ID(0x194f, 0x010d): /* 1824c */
		/* Set all output faders to unity gain */
		a = SC1810C_SEL_OUTPUT;
		c = 0x00;
		for (b = 0; b < 9; b++) {
			snd_s1810c_send_ctl_packet(dev, a, b, c, 0, MIXER_LEVEL_0DB);
			snd_s1810c_send_ctl_packet(dev, a, b, c, 1, MIXER_LEVEL_0DB);
		}

		/* Set
		 * Daw 1 -> Line out 1 (left), Daw 2 -> Line out 2 (right)
		 * Daw 3 -> Line out 3, (left) Daw 4 -> Line out 4 (right)
		 * Daw 5 -> Line out 5, (left) Daw 6 -> Line out 6 (right)
		 * Daw 7 -> Line out 7, (left) Daw 8 -> Line out 8 (right)
		 * Daw 9 -> SPDIF out 1, (left) Daw 10 -> SPDIF out 2 (right)
		 * Daw 11 -> ADAT out 1, (left) Daw 12 -> ADAT out 2 (right)
		 * Daw 13 -> ADAT out 3, (left) Daw 14 -> ADAT out 4 (right)
		 * Daw 15 -> ADAT out 5, (left) Daw 16 -> ADAT out 6 (right)
		 * Daw 17 -> ADAT out 7, (left) Daw 18 -> ADAT out 8 (right)
		 * Everything else muted
		 */
		a = SC1810C_SEL_MIXER;
		/* The first Daw channel is channel 18 */
		left = 18;

		for (c = 0; c < 9; c++) {
			right = left + 1;

			for (b = 0; b < 36; b++) {
				if (b == left) {
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 0, MIXER_LEVEL_0DB);
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 1, MIXER_LEVEL_MUTE);
				} else if (b == right) {
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 0, MIXER_LEVEL_MUTE);
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 1, MIXER_LEVEL_0DB);
				} else {
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 0, MIXER_LEVEL_MUTE);
					snd_s1810c_send_ctl_packet(dev,
							a, b, c, 1, MIXER_LEVEL_MUTE);
				}
			}
			left += 2;
		}
		break;
	}
	return 0;
}

/*
 * Sync state with the device and retrieve the requested field,
 * whose index is specified in (kctl->private_value & 0xFF),
 * from the received fields array.
 */
static int
snd_s1810c_get_switch_state(struct usb_mixer_interface *mixer,
			    struct snd_kcontrol *kctl, u32 *state)
{
	struct snd_usb_audio *chip = mixer->chip;
	struct s1810_mixer_state *private = mixer->private_data;
	u32 field = 0;
	u32 ctl_idx = (u32) (kctl->private_value & 0xFF);
	int ret;

	guard(mutex)(&private->usb_mutex);
	ret = snd_sc1810c_get_status_field(chip->dev, &field,
					   ctl_idx, &private->seqnum);
	if (ret < 0)
		return ret;

	*state = field;
	return ret;
}

/*
 * Send a control packet to the device for the control id
 * specified in (kctl->private_value >> 8) with value
 * specified in (kctl->private_value >> 16).
 */
static int
snd_s1810c_set_switch_state(struct usb_mixer_interface *mixer,
			    struct snd_kcontrol *kctl)
{
	struct snd_usb_audio *chip = mixer->chip;
	struct s1810_mixer_state *private = mixer->private_data;
	u32 pval = (u32) kctl->private_value;
	u32 ctl_id = (pval >> 8) & 0xFF;
	u32 ctl_val = (pval >> 16) & 0x1;

	guard(mutex)(&private->usb_mutex);
	return snd_s1810c_send_ctl_packet(chip->dev, 0, 0, 0, ctl_id, ctl_val);
}

/* Generic get/set/init functions for switch controls */

static int
snd_s1810c_switch_get(struct snd_kcontrol *kctl,
		      struct snd_ctl_elem_value *ctl_elem)
{
	struct usb_mixer_elem_list *list = snd_kcontrol_chip(kctl);
	struct usb_mixer_interface *mixer = list->mixer;
	struct s1810_mixer_state *private = mixer->private_data;
	u32 pval = (u32) kctl->private_value;
	u32 ctl_idx = pval & 0xFF;
	u32 state = 0;
	int ret;

	CLASS(snd_usb_lock, pm)(mixer->chip);
	if (pm.err < 0)
		return -EIO;

	guard(mutex)(&private->data_mutex);
	ret = snd_s1810c_get_switch_state(mixer, kctl, &state);
	if (ret < 0)
		return ret;

	switch (ctl_idx) {
	case SC1810C_STATE_LINE_SW:
	case SC1810C_STATE_AB_SW:
		ctl_elem->value.enumerated.item[0] = (int)state;
		break;
	default:
		ctl_elem->value.integer.value[0] = (long)state;
	}

	return 0;
}

static int
snd_s1810c_switch_set(struct snd_kcontrol *kctl,
		      struct snd_ctl_elem_value *ctl_elem)
{
	struct usb_mixer_elem_list *list = snd_kcontrol_chip(kctl);
	struct usb_mixer_interface *mixer = list->mixer;
	struct s1810_mixer_state *private = mixer->private_data;
	u32 pval = (u32) kctl->private_value;
	u32 ctl_idx = pval & 0xFF;
	u32 curval = 0;
	u32 newval = 0;
	int ret = 0;

	CLASS(snd_usb_lock, pm)(mixer->chip);
	if (pm.err < 0)
		return -EIO;

	guard(mutex)(&private->data_mutex);
	ret = snd_s1810c_get_switch_state(mixer, kctl, &curval);
	if (ret < 0)
		return ret;

	switch (ctl_idx) {
	case SC1810C_STATE_LINE_SW:
	case SC1810C_STATE_AB_SW:
		newval = (u32) ctl_elem->value.enumerated.item[0];
		break;
	default:
		newval = (u32) ctl_elem->value.integer.value[0];
	}

	if (curval == newval)
		return 0;

	kctl->private_value &= ~(0x1 << 16);
	kctl->private_value |= (unsigned int)(newval & 0x1) << 16;
	ret = snd_s1810c_set_switch_state(mixer, kctl);

	return (ret < 0) ? 0 : 1;
}

static int
snd_s1810c_switch_init(struct usb_mixer_interface *mixer,
		       const struct snd_kcontrol_new *new_kctl)
{
	struct snd_kcontrol *kctl;
	struct usb_mixer_elem_info *elem;

	elem = kzalloc_obj(struct usb_mixer_elem_info);
	if (!elem)
		return -ENOMEM;

	elem->head.mixer = mixer;
	elem->control = 0;
	elem->head.id = 0;
	elem->channels = 1;

	kctl = snd_ctl_new1(new_kctl, elem);
	if (!kctl) {
		kfree(elem);
		return -ENOMEM;
	}
	kctl->private_free = snd_usb_mixer_elem_free;

	return snd_usb_mixer_add_control(&elem->head, kctl);
}

static int
snd_s1810c_line_sw_info(struct snd_kcontrol *kctl,
			struct snd_ctl_elem_info *uinfo)
{
	static const char *const texts[2] = {
		"Preamp On (Mic/Inst)",
		"Preamp Off (Line in)"
	};

	return snd_ctl_enum_info(uinfo, 1, ARRAY_SIZE(texts), texts);
}

static const struct snd_kcontrol_new snd_s1810c_line_sw = {
	.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
	.name = "Line 1/2 Source Type",
	.info = snd_s1810c_line_sw_info,
	.get = snd_s1810c_switch_get,
	.put = snd_s1810c_switch_set,
	.private_value = (SC1810C_STATE_LINE_SW | SC1810C_CTL_LINE_SW << 8)
};

static const struct snd_kcontrol_new snd_s1810c_mute_sw = {
	.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
	.name = "Mute Main Out Switch",
	.info = snd_ctl_boolean_mono_info,
	.get = snd_s1810c_switch_get,
	.put = snd_s1810c_switch_set,
	.private_value = (SC1810C_STATE_MUTE_SW | SC1810C_CTL_MUTE_SW << 8)
};

static const struct snd_kcontrol_new snd_s1824c_mono_sw = {
	.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
	.name = "Mono Main Out Switch",
	.info = snd_ctl_boolean_mono_info,
	.get = snd_s1810c_switch_get,
	.put = snd_s1810c_switch_set,
	.private_value = (SC1824C_STATE_MONO_SW | SC1824C_CTL_MONO_SW << 8)
};

static const struct snd_kcontrol_new snd_s1810c_48v_sw = {
	.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
	.name = "48V Phantom Power On Mic Inputs Switch",
	.info = snd_ctl_boolean_mono_info,
	.get = snd_s1810c_switch_get,
	.put = snd_s1810c_switch_set,
	.private_value = (SC1810C_STATE_48V_SW | SC1810C_CTL_48V_SW << 8)
};

static int
snd_s1810c_ab_sw_info(struct snd_kcontrol *kctl,
		      struct snd_ctl_elem_info *uinfo)
{
	static const char *const texts[2] = {
		"1/2",
		"3/4"
	};

	return snd_ctl_enum_info(uinfo, 1, ARRAY_SIZE(texts), texts);
}

static const struct snd_kcontrol_new snd_s1810c_ab_sw = {
	.iface = SNDRV_CTL_ELEM_IFACE_MIXER,
	.name = "Headphone 1 Source Route",
	.info = snd_s1810c_ab_sw_info,
	.get = snd_s1810c_switch_get,
	.put = snd_s1810c_switch_set,
	.private_value = (SC1810C_STATE_AB_SW | SC1810C_CTL_AB_SW << 8)
};

static void snd_sc1810_mixer_state_free(struct usb_mixer_interface *mixer)
{
	struct s1810_mixer_state *private = mixer->private_data;
	kfree(private);
	mixer->private_data = NULL;
}

/* Entry point, called from mixer_quirks.c */
int snd_sc1810_init_mixer(struct usb_mixer_interface *mixer)
{
	struct s1810_mixer_state *private = NULL;
	struct snd_usb_audio *chip = mixer->chip;
	struct usb_device *dev = chip->dev;
	int ret = 0;

	/* Run this only once */
	if (!list_empty(&chip->mixer_list))
		return 0;

	ret = snd_s1810c_init_mixer_maps(chip);
	if (ret < 0)
		return ret;

	private = kzalloc_obj(struct s1810_mixer_state);
	if (!private)
		return -ENOMEM;

	mutex_init(&private->usb_mutex);
	mutex_init(&private->data_mutex);

	mixer->private_data = private;
	mixer->private_free = snd_sc1810_mixer_state_free;

	private->seqnum = 1;

	ret = snd_s1810c_switch_init(mixer, &snd_s1810c_line_sw);
	if (ret < 0)
		return ret;

	ret = snd_s1810c_switch_init(mixer, &snd_s1810c_mute_sw);
	if (ret < 0)
		return ret;

	ret = snd_s1810c_switch_init(mixer, &snd_s1810c_48v_sw);
	if (ret < 0)
		return ret;

	switch (chip->usb_id) {
	case USB_ID(0x194f, 0x010c): /* Presonus Studio 1810c */
		dev_info(&dev->dev,
			 "Presonus Studio 1810c, device_setup: %u\n", chip->setup);
		if (chip->setup == 1)
			dev_info(&dev->dev, "(8out/18in @ 48kHz)\n");
		else if (chip->setup == 2)
			dev_info(&dev->dev, "(6out/8in @ 192kHz)\n");
		else
			dev_info(&dev->dev, "(8out/14in @ 96kHz)\n");

		ret = snd_s1810c_switch_init(mixer, &snd_s1810c_ab_sw);
		if (ret < 0)
			return ret;

		break;
	case USB_ID(0x194f, 0x0107): /* Presonus Studio 1824 */
	case USB_ID(0x194f, 0x010d): /* Presonus Studio 1824c */
		ret = snd_s1810c_switch_init(mixer, &snd_s1824c_mono_sw);
		if (ret < 0)
			return ret;

		break;
	}

	return ret;
}
